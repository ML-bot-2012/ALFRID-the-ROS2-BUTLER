"""
ALFRID Robot SLAM System (Pi5)
Property of 5KROBOTICS & MALHAR LABADE
"""
__version__ = '1.0.0'
__author__ = 'MALHAR LABADE'
__copyright__ = 'Copyright 2025, 5KROBOTICS & MALHAR LABADE'
