def start_nodes():
    print("ALFRID GPIO - Run: ros2 launch butler_gpio pi3b_launch.py")
