"""
ALFRID Robot GPIO Control (Pi3B+)
Property of 5KROBOTICS & MALHAR LABADE
"""
__version__ = '1.0.0'
__author__ = 'MALHAR LABADE'
__copyright__ = 'Copyright 2025, 5KROBOTICS & MALHAR LABADE'
